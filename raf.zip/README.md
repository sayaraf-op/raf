# TelegramGPT_Bot

Communicate with your own chat in Telegram (in a voice or text) and get fast answers from ChatGPT.

## Join:

[GPT-chatbot](https://t.me/Conversation_GPT_Bot/)

- /start - to begin
- /new - to start new session of conversation
