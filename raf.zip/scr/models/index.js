const { bot, INITIAL_SESSION } = require("./telegramBot");

module.exports = {
  bot,
  INITIAL_SESSION,
};
